import numpy as np
from skimage import io
from matplotlib import pyplot as plt
from scipy.stats import multivariate_normal
from PIL import Image

# ------------------------------------------------------------
image = io.imread("duck.jpg")
image = np.array(image)
print(image.shape)
H = image.shape[0]
W = image.shape[1]
D = image.shape[2]


"""
dock local: x,y
(440,100) to (570,410)
"""
# Positive Sample
# prepare the duck Img array
# 130 * 310
duck_array = np.zeros((310, 130, 3), dtype=np.uint8)

for i in range(310): # H
    for j in range(130): # W
        duck_array[i][j] = image[i+100][j+440]

print(duck_array.shape)
solve_Img = Image.fromarray(duck_array, mode="RGB")
solve_Img.save("duck_crop.jpg")


"""
sky local: x,y
(50,20) to (200,110)
"""
# Negative Sample
# prepare the BlueSky Img array
sky_array = np.zeros((90, 150, 3), dtype=np.uint8)

for i in range(90): # H
    for j in range(150): # W
        sky_array[i][j] = image[i+20][j+50]

print(sky_array.shape)
solve_Img = Image.fromarray(sky_array, mode="RGB")
solve_Img.save("sky_crop.jpg")

trainP = duck_array
trainP = trainP.reshape(310*130,3)
print(trainP.shape)

trainN =sky_array
trainN = trainN.reshape(90*150,3)
print(trainN.shape)

tmp1 = np.cov(trainP,rowvar=False)
cov_duck = np.diag(np.diag(tmp1)) # 斜對角矩陣 只有斜線有0

tmp2 = np.cov(trainN,rowvar=False)
cov_sky = np.diag(np.diag(tmp2))
image_mark_duck = np.array(image.shape, dtype=np.uint8)
for i in range(duck_array.shape[0]):
    for j in range(duck_array.shape[1]):
        r1 = image_mark_duck[i][j] = multivariate_normal.pdf(duck_array[i][j], trainP.mean(axis=0), cov_duck)
        r2 = image_mark_duck[i][j] = multivariate_normal.pdf(sky_array[i][j], trainN.mean(axis=0), cov_sky)

        if (r1 > r2):
            image_mark_duck[i][j][0] = 255
            image_mark_duck[i][j][1] = 0
            image_mark_duck[i][j][2] = 0
    print("Row", i)

img = Image.fromarray(image_mark_duck)
img.save("duck_stats.jpg")


"""
trainP = duck_array
trainN = sky_array


# 多維度
train2 = np.array([
    [10,30], [20,40], [30,50]
])

xy1 = np.array([20,45])
xy2 = np.array([45,20])

tmp = np.cov(image,rowvar=False)
cov2 = np.diag(np.diag(tmp)) # 斜對角矩陣 只有斜線有0

r1 = multivariate_normal.pdf(image, trainP.mean(axis=0), cov2) # ！axis = 0 3個人， 每個人有兩個成績,從row看
r2 = multivariate_normal.pdf(image, trainN.mean(axis=0), cov2)

print(r1,r2)

# 看每一個pixel比較像背景還是花
# 每個格子 分成16個格子 在針對每一個格子做運算 每一個格子分別當做一個人考了27個科目

"""