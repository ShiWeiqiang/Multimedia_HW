#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar 20 12:51:35 2018

@author: shiweiqiang Econ4A 403574063 Group19
"""
import os
import numpy as np
from PIL import Image
print("Practice 2")
im = np.array(Image.open("sky2.jpg"))
print(im.shape)
frame_shape = (30, im.shape[0], im.shape[1], im.shape[2])
frames = np.zeros(shape=frame_shape, dtype = np.uint8)




if not os.path.isdir("sky/"):
    os.makedirs("sky/")
for i in range(len(frames)):
    img = Image.fromarray(frames[i])
    fname = "sky/"+str(i+1)+".jpg"
    img.save(fname)
    